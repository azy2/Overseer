"""test mixed tabs and spaces"""
from __future__ import print_function

def spaces_func():
    """yo"""
    print("yo")

def tab_func():
	"""yo""" # [mixed-indentation]
	print("yo") # [mixed-indentation]
