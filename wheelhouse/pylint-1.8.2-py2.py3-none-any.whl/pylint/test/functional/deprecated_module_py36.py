"""Test deprecated modules from Python 3.6."""
# pylint: disable=unused-import

import optparse # [deprecated-module]
import tkinter.tix # [deprecated-module]
