"""version information"""

# taken from http://stackoverflow.com/a/17626524/1836144
# The following line *must* be the last in the module, exactly as formatted:
# could also use advice from
# https://packaging.python.org/guides/single-sourcing-package-version/
__version__ = '0.7.4'
