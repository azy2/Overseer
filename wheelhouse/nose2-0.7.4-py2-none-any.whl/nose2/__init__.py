from nose2._version import __version__
from nose2.main import discover, main
